enable permission:
chmod +x <shell script> (misalnya chmod +x compileOS.sh)
chmod +x loadFile

kompilasi:
./compileOS<nomor project>.sh
./compileUprog.sh (pada P3)

run:
bochs -f opsys.bxrc
