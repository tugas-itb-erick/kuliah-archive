File tinggimhs.csv menyimpan tinggi mahasiswa dalam satuan cm.
File commentlength.csv menyimpan panjang komentar mahasiswa dalam satuan kata.
File ujian.csv menyimpan nilai ujian matakuliah sastra teknik informatika yang dikerjakan oleh X. 
File kejahatan.csv menyimpan data hari dan banyaknya kejahatan yang terjadi pada hari yang bersangkutan. 