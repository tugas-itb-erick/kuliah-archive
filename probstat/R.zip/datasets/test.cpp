#include <bits/stdc++.h>
using namespace std;

int randInt(int small, int big) {
	return rand() % (big-small+1) + small;
}

int main() {
	srand (time(NULL));
	ofstream outfile;

	// outfile.open("ujian.csv");
	// for (int i=0; i<200; i++) {
	// 	int rnd = randInt(0, 150);
	// 	if (rnd > 100) rnd = randInt(75, 100);
	// 	outfile << rnd << endl;
	// }

	// outfile.close();

	outfile.open("kejahatan.csv");
	outfile << "hari-ke,status" << endl;
	for (int i=1; i<=365*3; i++) {
		int rnd = randInt(1, 1000);
		outfile << i << ",";
		if (rnd >= 1 && rnd <= 950) {
			outfile << 0 << endl;
		} else if (rnd > 950 && rnd <= 980) {
			outfile << 1 << endl;
		} else if (rnd > 980 && rnd <= 992) {
			outfile << 2 << endl;
		} else if (rnd > 992 && rnd <= 997) {
			outfile << 3 << endl;
		} else {
			outfile << randInt(4,5) << endl;
		}
	}

	outfile.close();

	return 0;
}